/*
 * Gautam Singh
 * Parity.c
 * Description: Defines the ParityOnBytes() function
 */

#include "Parity.h"

PARITY ParityOnBytes(char* buff, int buffLen) {
	int i; //counter for my loop
	int counter = 0; //counter to count number of 1s in the array

	for (i = 0; i < buffLen; i++) {
		if (*buff == "1") {
			counter++;
		}
		else if (*buff != '0') {
			return(PAR_ERROR);
		}
		buff++;
	}

	//check if even or odd number of 1s
	if (counter % 2 == 0) {
		printf("Number of ones %i", counter);
		return(PAR_EVEN);
	}
	else {
		printf("Number of ones %i", counter);
		return(PAR_ODD);
	}
}