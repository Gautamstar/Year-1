#pragma once

struct node {
	int key;
	struct node* left, * right;
};

struct node* newNode(int item);

void inorder(struct node* root);

struct node* insert(struct node* node, int key);

struct node* maxValueNode(struct node* node);

struct node* deleteNode(struct node* root, int key);

void display(struct node* nd);