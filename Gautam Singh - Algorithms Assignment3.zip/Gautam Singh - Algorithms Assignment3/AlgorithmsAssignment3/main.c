#include <stdio.h>
#include <stdlib.h>
#include "node.h"

int main() {
	struct node* root = NULL;
	int count = 0;
	for (int i = 0; i < 7; i++) {
		int n = rand() % 100 + 1;
		printf("%d \n", n);
		insert(root, n);
		count++;
	}
	inorder(root);
	printf("Maximum Value: %d\n", maxValueNode(root)->key);
	//display(root);
	printf("Numbers of nodes: %d", count);
}