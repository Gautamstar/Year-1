#include <iostream>
#include <algorithm>

using namespace std;

struct Location {
    double latitude, longitude;
};

int main() {
    int firstNum = 5;
    int secondNum = 6;
    int last = NULL;

	cout << max(11, 5);
	cout << max(2, 5, 7);
    int a[] = { 1,2,3,4,5 };
    cout << max(a);

    swap(firstNum, secondNum);
    swap(&firstNum, &secondNum);
    Location loc1;
    Location loc2;
    swap(loc1, loc2);
    swap(&loc1, &loc2);

    multiply(firstNum, secondNum);
    multiply(5, 5, last);
    
    return 0;
}

int max(int num1, int num2)// Takes in two double parameters.
{   // Calculates the max of two numbers
    if (num1 > num2)
    {
        return num1;
    }
    else
    {
        return num2; 
    }
    return 0;
}
int max(int num1, int num2, int num3)
{ 
    if (num1 > num2 and num1 > num3)
    {
        return num1; 
    }
    else if (num2 > num1 and num2 > num1)
    {
        return num2;
    }
    else
    {
        return num3; 
    }
    return 0;
}
int max(int array[]) {
    for (int i = 0; i < 5; i++) {
        int highestNumber = array[i];
        int nextNum = array[i];

        if (highestNumber < nextNum) {
            highestNumber = nextNum;
        }
        return highestNumber;
    }
}

void swap(int* a, int* b) { //using pointers
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
void swap(int &a, int &b) { //using references
    int temp;
    temp = a;
    a = b;
    b = temp;
}

Location swap(Location* a, Location* b) {
    Location temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
Location swap(Location &a, Location &b) {
    Location temp;
    temp = a;
    a = b;
    b = temp;
}

int multiply(int a, int b, int c) {
    if (c == NULL) {
        c = 1;
    }
    int total = (a * b * c);
    return total;
}
int multiply(int a, int b) {
    int total = (a * b);
    return total;
}
/* question 4-c
* You cannot add a third function that has the same name and only 2 integer arguments because that is not overloading, it is the exact same function.
* The function from part b of this question does the same thing.
*/

