#pragma once

typedef struct Patients {
    long patientNumber;
    int age;
}PATIENT;

struct node {
    PATIENT p;
    struct node* next;
};
typedef struct node node;

struct queue {
    int count;
    node* front;
    node* rear;
};
typedef struct queue queue;

void traverse(queue* q);
void traverseR(queue* q);