#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

void initialize(queue* q) {
    q->count = 0;
    q->front = NULL;
    q->rear = NULL;
}

int isempty(queue* q) {
    return (q->rear == NULL);
}

void enqueue(queue* q, PATIENT value) {
    node* tmp;
    tmp = malloc(sizeof(node));
    tmp->p = value;
    tmp->next = NULL;
    if (!isempty(q)) {
        q->rear->next = tmp;
        q->rear = tmp;
    }
    else {
        q->front = q->rear = tmp;
    }
    q->count++;
}

void traverse(queue* q) {
    if (q->rear == NULL) {
        return;
    }
    else {
        printf("Patient Number: %d, Patient age: %d\n\n", q->rear->p.patientNumber, q->rear->p.age);
        traverse(q->rear->next);
    }
}
void traverseR(queue* q) {
    if (q->front == NULL) {
        return;
    }
    else {
        q->front->next = q->front->next - 1;
        traverseR(q);
        printf("Patient Number: %d, Patient age: %d\n\n", q->rear->p.patientNumber, q->rear->p.age);
    }
}

void dequeue(queue* q) {
    node* tmp;
    PATIENT n = q->front->p;
    tmp = q->front;
    q->front = q->front->next;
    q->count--;
    free(tmp);
}

void display(node* head) {
    if (head == NULL)
    {
        printf("NULL\n");
    }
    else {
        printf("Patient Number: %d, Patent age: %d\n\n", head->p.patientNumber, head->p.age);
        display(head->next);
    }
}