/* Gautam Singh
Data Structures and Algorithms
*/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int main() {
    queue* q;
    q = malloc(sizeof(queue));
    initialize(q);
    int numPatients;
    printf("How many random patients should be generated?");
    scanf("%d", &numPatients);

    for (int i = 0; i < numPatients; i++) {
        PATIENT p1;
        p1.age = (rand() % 99 + 1);
        p1.patientNumber = (rand() % 999999999 + 900000000);
        enqueue(q, p1);
    }
    printf("Queue before dequeue\n");
    traverse(q);
    traverseR(q);
    display(q);
    dequeue(q);
    printf("Queue after dequeue\n");
    traverse(q);
    traverseR(q);
    display(q);
    return 0;
}