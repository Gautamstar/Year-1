// GAUTAM SINGH NETWORKING A3
#include <windows.networking.sockets.h>
#include <iostream>
#include <fstream>
#pragma comment(lib, "Ws2_32.lib")
#include <string>
#include <string.h>
using namespace std;
string convert_string(char* a);

string convert_string(char* a) //converting char to string
{
	string s(a);
	return s;
}
int main()
{
	string table[2048];
	int count = 0;
	// Read from file
	ifstream file;
	file.open("data.txt");
	while (!file.eof()) //check end of file
	{
		getline(file, table[count]); 
		count++;
	}
	//starts Winsock DLLs		
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
		return 0;

	//create server socket
	SOCKET ServerSocket;
	ServerSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (ServerSocket == INVALID_SOCKET) {
		WSACleanup();
		return 0;
	}

	//binds socket to address
	sockaddr_in SvrAddr;
	SvrAddr.sin_family = AF_INET;
	SvrAddr.sin_addr.s_addr = INADDR_ANY;
	SvrAddr.sin_port = htons(27000);
	if (bind(ServerSocket, (struct sockaddr*)&SvrAddr, sizeof(SvrAddr)) == SOCKET_ERROR)
	{
		closesocket(ServerSocket);
		WSACleanup();
		return 0;
	}

	//listen on a socket
	if (listen(ServerSocket, 1) == SOCKET_ERROR) {
		closesocket(ServerSocket);
		WSACleanup();
		return 0;
	}

	cout << "Waiting for client connection\n" << endl;

	//accepts a connection from a client
	SOCKET ConnectionSocket;
	ConnectionSocket = SOCKET_ERROR;
	if ((ConnectionSocket = accept(ServerSocket, NULL, NULL)) == SOCKET_ERROR) {
		closesocket(ServerSocket);
		WSACleanup();
		return 0;
	}
	cout << "Connection Established" << endl;
	bool running = true;
	//datafiles
	ofstream Myfile;
	Myfile.open("data.txt", ios::out);
	
	while (running) {

		
		//receives RxBuffer
		char RxBuffer[2048] = {};
		recv(ConnectionSocket, RxBuffer, sizeof(RxBuffer), 0);
		if (RxBuffer[0] == '$') {
			break; //exit conditon
		}
		cout << "Msg Rx: " << RxBuffer << endl;
		string line = convert_string(RxBuffer); //convert to string
		table[count] = line;

		char TxBuffer[2048] = "--Recieved--";

		send(ConnectionSocket, TxBuffer, sizeof(TxBuffer), 0); //send reply

		//Myfile << RxBuffer;
		count++;
	}
	for (int j = 0; j < count; j++) { //write files line by line
		if (!table[j].empty()) {
				Myfile << table[j] << endl; //table[] stores each line of posts
		}
	}
	Myfile.close(); //closing files
	file.close();

	closesocket(ConnectionSocket);	//closes incoming socket
	closesocket(ServerSocket);	    //closes server socket	
	WSACleanup();					//frees Winsock resources

	return 1;
}
