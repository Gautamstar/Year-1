// GAUTAM SINGH NETWORKING A3
#include <windows.networking.sockets.h>
#pragma comment(lib, "Ws2_32.lib")
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

void createSinglePost(char* post);
void createMultiplePosts(char* posts);

SOCKET ClientSocket1; //global socket
string table[2048]; //table to store all posts for multiple posts

int main()
{
	//starts Winsock DLLs
	WSADATA wsaData;
	if ((WSAStartup(MAKEWORD(2, 2), &wsaData)) != 0) {
		return 0;
	}

	//initializes socket. SOCK_STREAM: TCP
	SOCKET ClientSocket;
	ClientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (ClientSocket == INVALID_SOCKET) {
		WSACleanup();
		return 0;
	}

	//Connect socket to specified server
	sockaddr_in SvrAddr;
	SvrAddr.sin_family = AF_INET;						//Address family type itnernet
	SvrAddr.sin_port = htons(27000);					//port (host to network conversion)
	SvrAddr.sin_addr.s_addr = inet_addr("127.0.0.1");	//IP address
	if ((connect(ClientSocket, (struct sockaddr*)&SvrAddr, sizeof(SvrAddr))) == SOCKET_ERROR) {
		closesocket(ClientSocket);
		WSACleanup();
		return 0;
	}

	ClientSocket1 = ClientSocket;  //global socket creation 
	bool running = true;

	while (running) {
		int response1 = 0; //choice variable
		char TxBuffer[2048] = {};
		char post[2048] = {};

		//menu and getting responses
		cout << "\nMenu - enter the correct number for the corresponding action!" << endl;
		cout << "1. Send a single post." << endl;
		cout << "2. Send multiple posts." << endl;
		cout << "3. Exit" << endl;
		cin >> response1;

		if (response1 == 1) {
			createSinglePost(post); //calling multiple posts
		}
		if (response1 == 2) {
			createMultiplePosts(post); //calling multiple posts
		}
		if (response1 == 3) {
			string fullText = {};
			fullText = "$"; //if exit is selected then then the $ is sent to server
			const char* TxBuffer = fullText.c_str(); 
			send(ClientSocket1, TxBuffer, strlen(TxBuffer), 0); //sending $ to server to exit.
		}
	}
	//closes connection and socket
	closesocket(ClientSocket);
	closesocket(ClientSocket1);
	//frees Winsock DLL resources
	WSACleanup();

	return 1;
}
void createSinglePost(char* post) {
	int response2 = 0; //second menu response var

	int postsNumber = {}; //for loop

	string text = {}; //stores post text

	string author = {};//stores post author

	string topic = {}; //stores post topic

	string fullText = {}; //stores the entire singular post
		
		//sub lvl menu
		cout << "1. Anonymous Post" << endl;
		cout << "2. Post with Author" << endl;
		cout << "3. Post with Topic" << endl;
		cout << "4. Post with Author and Topic" << endl;
		cout << "5. Exit" << endl;
		cin >> response2;
		cin.ignore();

		if (response2 == 1) {
			string fullText = {}; //new string to save to
			cout << "Enter an anonymous post to transmit." << endl;
			getline(cin, text);
			fullText = text + ", Author: none, Topic: none."; //anonymous

			const char* TxBuffer = fullText.c_str(); //turn string to char buffer
			char RxBuffer[2048] = {}; //buffer for recieving 
			send(ClientSocket1, TxBuffer, strlen(TxBuffer), 0); //sending post
			recv(ClientSocket1, RxBuffer, sizeof(RxBuffer), 0); //recieving conformation 
			cout << RxBuffer << endl;
		}
		if (response2 == 2) {
			string fullText = {}; //new string to save to
			cout << "Enter an post to transmit." << endl;
			getline(cin, text);

			cout << "Enter an Author name." << endl; //post and author
			getline(cin, author);

			fullText = text + ", Author: " + author + ", Topic: none.";

			const char* TxBuffer = fullText.c_str(); //turn string to char buffer
			char RxBuffer[2048] = {}; //buffer for recieving 
			send(ClientSocket1, TxBuffer, strlen(TxBuffer), 0); //sending post
			recv(ClientSocket1, RxBuffer, sizeof(RxBuffer), 0); //recieving confirmation 
			cout << RxBuffer << endl;
		}
		if (response2 == 3) {
			string fullText = {};
			cout << "Enter an post to transmit." << endl; //get post
			getline(cin, text);

			cout << "Enter an Topic name." << endl; //get topic
			getline(cin, topic);

			fullText = text + " , Author: none" +  ", Topic: " + topic;

			const char* TxBuffer = fullText.c_str();
			char RxBuffer[2048] = {};
			send(ClientSocket1, TxBuffer, strlen(TxBuffer), 0);
			recv(ClientSocket1, RxBuffer, sizeof(RxBuffer), 0);
			cout << RxBuffer << endl;
		}
		if (response2 == 4) {
			string fullText = {};
			cout << "Enter an post to transmit." << endl; //get post
			getline(cin, text);

			cout << "Enter an Author name." << endl; //get author
			getline(cin, author);

			cout << "Enter an Topic name." << endl; //get topic
			getline(cin, topic); 

			 fullText = text + ", Author: " + author + ", Topic: " + topic; //store all

			const char* TxBuffer = fullText.c_str(); 
			char RxBuffer[2048] = {};
			send(ClientSocket1, TxBuffer, strlen(TxBuffer), 0);
			recv(ClientSocket1, RxBuffer, sizeof(RxBuffer), 0);
			cout << RxBuffer << endl;
		}
		if (response2 == 5) {
			string fullText = {};
			fullText = "$"; //exit text
			const char* TxBuffer = fullText.c_str();
			send(ClientSocket1, TxBuffer, strlen(TxBuffer), 0); //sending exit text
		}
}

void createMultiplePosts(char* post) {
	    int postsNumber = {}; //for loop
		string text = {};
		string author = {};
		string topic = {};
		 // stores all posts
		string fullText = {};
		
		cout << "Enter the number of posts. (Int)" << endl;
		cin >> postsNumber; //gets number of multiple posts
		int count = 0; //stores the column of the table
		for (int i = 0; i < postsNumber; i++) {
			int response2 = 0;
			cout << "1. Anonymous Post" << endl; //second lvl2 menu
			cout << "2. Post with Author" << endl;
			cout << "3. Post with Topic" << endl;
			cout << "4. Post with Author and Topic" << endl;
			cout << "5. Exit" << endl;
			cin >> response2;
			cin.ignore();

			if (response2 == 1) { //gets only post
				cout << "Enter an anonymous post to transmit." << endl;
				getline(cin, text);
				fullText = text + ", Author: none, Topic: none.\n"; //stores post 
				table[count] = fullText; //adds the post to array
			}
			if (response2 == 2) { //gets only post and author
				cout << "Enter an post to transmit." << endl;
				getline(cin, text);

				cout << "Enter an Author name." << endl;
				getline(cin, author);

				fullText = text + ", Author: " + author + ", Topic: none.\n";

				table[count] = fullText; //adds the post to array
			}
			if (response2 == 3) { //gets only post and topic
				cout << "Enter an post to transmit." << endl;
				getline(cin, text);

				cout << "Enter an Topic name." << endl;
				getline(cin, topic);
				fullText = text + " , Author: none" + ", Topic: " + topic + "\n";
				table[count] = fullText; //adds the post to array
			}
			if (response2 == 4) { //gets all 3
				cout << "Enter an post to transmit." << endl;
				getline(cin, text);

				cout << "Enter an Author name." << endl;
				getline(cin, author);

				cout << "Enter an Topic name." << endl;
				getline(cin, topic);

				fullText = text + ", Author: " + author + ", Topic: " + topic + "\n";
				table[count] = fullText; //adds the post to array
			}
			if (response2 == 5) {
				string fullText = {};
				fullText = "$"; //exit text
				const char* TxBuffer = fullText.c_str();
				send(ClientSocket1, TxBuffer, strlen(TxBuffer), 0); //sending exit command
			}
			count++; //iterate to next index of array
		}
		for (int j = 0; j < count; j++) { //goes through every index
			const char* TxBuffer = table[j].c_str(); //convert string to char
			char RxBuffer[2048] = {}; //buffer to recieve 
			send(ClientSocket1, TxBuffer, strlen(TxBuffer), 0); //send char array to server
			recv(ClientSocket1, RxBuffer, sizeof(RxBuffer), 0); //recieve confirmation 
			cout << RxBuffer << endl;
		}
}