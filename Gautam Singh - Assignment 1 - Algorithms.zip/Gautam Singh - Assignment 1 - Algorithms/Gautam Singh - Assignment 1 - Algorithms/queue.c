#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

void initialize(queue* q){
    q->count = 0;
    q->front = NULL;
    q->rear = NULL;
}

int isempty(queue* q){
    return (q->rear == NULL);
}

void enqueue(queue* q, PATIENT value){
    node* tmp;
    tmp = malloc(sizeof(node));
    tmp->p = value;
    tmp->next = NULL;
    if (!isempty(q)){
        q->rear->next = tmp;
        q->rear = tmp;
    }else{
        q->front = q->rear = tmp;
    }
    q->count++;
}

void dequeue(queue* q){
    node* tmp;
    PATIENT n = q->front->p;
    tmp = q->front;
    q->front = q->front->next;
    q->count--;
    free(tmp);
}

void display(node* head){
    if (head == NULL)
    {
        printf("NULL\n");
    }else{
        printf("Patient Number: %d, Patent age: %d\n\n", head->p.patientNumber, head->p.age);
        display(head->next);
    }
}