#ifndef VOTEON_H
#define VOTEON_H

/* VoteOn.h : Header file for FEC via repetition and voting*/

// Function declarations 
int  VoteOn(void* Instances[], int nInstances, int nSize);

#endif //VOTEON_H