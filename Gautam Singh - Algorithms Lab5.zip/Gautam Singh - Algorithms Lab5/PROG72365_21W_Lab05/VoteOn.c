/* Gautam Singh
//Pick the an elemennt in the list
//Compare the element to every other element
//Pick the next element in the list
//Repeat
*/

#include<string.h>
#include "VoteOn.h"

int  VoteOn(void* Instances[], int nInstances, int nSize) {
	//Location fo the item that appears the most
	int maxIndex = -1; //Index of the item in majority - initialize to -1.
	//Which element is the most
	int maxRepeats = 0; //highest number of repeats

	for (int i = 0; i < nInstances; i++) {
		int currentRepeats = 0;
		for (int g = i + 1; g < nInstances; g++) {
			if (memcmp(Instances[i], Instances[g], nSize) == 0) {
				// Count of the current item
				currentRepeats++;
			}
		}
		if (currentRepeats > maxRepeats) {
			maxRepeats = currentRepeats;
			maxIndex = i; //i is the index of the current item
		}
		else if (currentRepeats == maxRepeats) {
			maxIndex = -1; //set back to error because no majority
		}
	} 
	return(maxIndex);
}