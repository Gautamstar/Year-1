
#pragma once
#define LENGTH 10

typedef struct StudentName {
	char firstName[LENGTH];
	char middleName[LENGTH];
	char lastName[LENGTH];
};

typedef struct Student {
	int studentID;
	struct StudentName;
};

void printStruct(struct Student array[]);