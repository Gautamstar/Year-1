/*
Gautam Singh
November 16, 2020
This program creates a student structure, adds it to an array and then outputs it
*/

#include <stdio.h>
#include <stdlib.h>
#include "q4.h"
#define LEN 5
int main(void) {

	struct Student* ptd;
	ptd = (struct Student*)malloc(sizeof(struct Student));

	if (ptd == NULL) {
		puts("Memory Allocation failed.");
		exit(EXIT_FAILURE);
	}

	struct Student first = { 2000000001, "Beep\t", "B\t", "Boop\n" };
	struct Student second = { 2000000011, "Wario\t", "E\t", "Nintendo\n" };
	struct Student third = { 2000000111, "Bowser\t", "B\t", "Bintendo\n" };
	struct Student fourth = { 2000001111, "Bitsy\t", "W\t", "Bottom\n" };
	struct Student fifth = { 2000011111, "John\t", "F\t", "Kenedy\n" };

	struct Student* firstPtr = &first;
	struct Student* secondPtr = &second;
	struct Student* thirdPtr = &third;
	struct Student* fourthPtr = &fourth;
	struct Student* fifthPtr = &fifth;

	struct Student* Array[LEN] = { firstPtr, secondPtr, thirdPtr, fourthPtr, fifthPtr };

	printStruct(Array);

	free(ptd);

	return 0;
}

void printStruct(struct Student Array[]) { 
	for (int i = 0; i < 5; i++) {
		printf("%d -- %s, %s %c. \n", (void*) &Array[i].studentID, (void*) &Array[i].firstName, (void*) &Array[i].middleName[0], (void*) &Array[i].lastName);
	}
}